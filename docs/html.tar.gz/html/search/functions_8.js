var searchData=
[
  ['parent_5fpath_113',['parent_path',['../file_8c.html#a48f9cbd6330096d4aeaf42ce36676f2f',1,'parent_path(char *path):&#160;file.c'],['../file_8h.html#a48f9cbd6330096d4aeaf42ce36676f2f',1,'parent_path(char *path):&#160;file.c']]]
];
