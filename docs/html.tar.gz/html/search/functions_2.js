var searchData=
[
  ['error_95',['error',['../util_8c.html#aea5d2d1feb928f411bedf7b5a16d373a',1,'error(char *fmt,...):&#160;util.c'],['../util_8h.html#aec747473ef86eac8228c4a97f5ff6535',1,'error(char *,...):&#160;util.c']]],
  ['expect_96',['expect',['../util_8c.html#a020850fe2d1cf255c433fd464b3c9d80',1,'expect(int line, int expected, int actual):&#160;util.c'],['../util_8h.html#a020850fe2d1cf255c433fd464b3c9d80',1,'expect(int line, int expected, int actual):&#160;util.c']]],
  ['expect_5fbool_97',['expect_bool',['../util_8c.html#a5dd136c36cc062f86155e0a259a8446c',1,'expect_bool(int line, bool expected, bool actual):&#160;util.c'],['../util_8h.html#a5dd136c36cc062f86155e0a259a8446c',1,'expect_bool(int line, bool expected, bool actual):&#160;util.c']]],
  ['expect_5fptr_98',['expect_ptr',['../util_8c.html#a7586aeeffb85c74f201e84361678962c',1,'expect_ptr(int line, void *expected, void *actual):&#160;util.c'],['../util_8h.html#a7586aeeffb85c74f201e84361678962c',1,'expect_ptr(int line, void *expected, void *actual):&#160;util.c']]],
  ['expect_5fstr_99',['expect_str',['../util_8c.html#a73fae2df699d3f890f673056293c77fb',1,'expect_str(int line, char *expected, char *actual):&#160;util.c'],['../util_8h.html#a73fae2df699d3f890f673056293c77fb',1,'expect_str(int line, char *expected, char *actual):&#160;util.c']]],
  ['extension_100',['extension',['../file_8c.html#aa17a7ccdebeb4f845f315df94982af52',1,'extension(char *path):&#160;file.c'],['../file_8h.html#aa17a7ccdebeb4f845f315df94982af52',1,'extension(char *path):&#160;file.c']]]
];
