var searchData=
[
  ['vector_5flast_120',['Vector_last',['../util_8c.html#a4a1e83f783c526160e9351408917b4bd',1,'Vector_last(Vector *vec):&#160;util.c'],['../util_8h.html#a46e0401d6546666f2bde41b0121b9ef2',1,'Vector_last(Vector *):&#160;util.c']]],
  ['vector_5fpop_121',['Vector_pop',['../util_8c.html#a1dbfefa24cf25fbf380b54b2b0e77cb9',1,'Vector_pop(Vector *vec):&#160;util.c'],['../util_8h.html#a5d0a3ea1bd8b7ff57e08228c1e8ba226',1,'Vector_pop(Vector *):&#160;util.c']]],
  ['vector_5fpush_122',['Vector_push',['../util_8c.html#a5fbeeb38a37fafacd9941b490497cf36',1,'Vector_push(Vector *vec, void *elem):&#160;util.c'],['../util_8h.html#a775303ac9b1eab00d686195916a064ec',1,'Vector_push(Vector *, void *):&#160;util.c']]]
];
