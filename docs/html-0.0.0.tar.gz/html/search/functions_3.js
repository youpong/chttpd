var searchData=
[
  ['filename_101',['filename',['../file_8c.html#a0b4ab0550234c06392763ab4be06c245',1,'filename(char *path):&#160;file.c'],['../file_8h.html#a0b4ab0550234c06392763ab4be06c245',1,'filename(char *path):&#160;file.c']]]
];
